﻿public interface IWeapon
{
    void Attack(ITarget target);
}