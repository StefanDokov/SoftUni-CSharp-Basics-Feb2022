﻿namespace WildFarm.Models.Interfaces;

public interface IFeline : IMammal
{
    string Breed { get; }
}